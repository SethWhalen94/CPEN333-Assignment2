#ifndef __AirFilter__
#define __AirFilter__
#include"GlobalDefinitions.h"

class AirFilter
{
public:
	int part_number;
	AirFilter (int num) : part_number(num)
	{}

};


#endif // !AirFilter

