#ifndef __GlobalDefinitions__
#define __GlobalDefinitions__
#include "rt.h"
#include <list>

//CMutex DrawMutex("MyMutex");


#endif // !__GlobalDefinitions__

