#ifndef __OilFilter__
#define __OilFilter__
#include"GlobalDefinitions.h"

class OilFilter
{
public:
	int part_number;
	OilFilter(int num) : part_number(num)
	{}
};


#endif // !OilFilter
