#ifndef __Recycling__
#define __Recycling__
#include"GlobalDefinitions.h"

class Recycling
{

public:
	void Recycle(int stuff)
	{
		//.Wait();
		//MOVE_CURSOR(0, 20);
		cout << "Recycling part with part number " << stuff << " ....\n";
		//.Signal();

	}

};


#endif // !Recycling
