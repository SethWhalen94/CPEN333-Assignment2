#ifndef __Tire__
#define __Tire__
#include"GlobalDefinitions.h"

class Tire
{
public:
	int size;
	Tire(int num) : size(num)
	{}
};


#endif // !Tire
